<?php $__env->startSection('title'); ?>
Bands 🎸
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <h1>All bands</h1>


    <?php $__currentLoopData = $bands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $band): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="card mb-3" style="max-width: 540px;">
            <div class="row g-0">
            <div class="col-md-4">
                <img id="imgBandCard" src="<?php echo e($band->photo ? asset('storage/' . $band->photo) : asset('img/nophoto.png')); ?>" class="img-fluid rounded-start" alt="...">
            </div>
            <div class="col-md-8">
                <div class="card-body">
                <h5 class="card-title"><?php echo e($band->name); ?></h5>
                <p class="card-text">
                    <a href="<?php echo e(route('albums.show', $band->id)); ?>">
                        <button class="btn btn-primary">
                            <?php if( $band->numberOfAlbums > 0): ?>
                                View <?php echo e($band->numberOfAlbums); ?> albums
                            <?php else: ?>
                                View band
                            <?php endif; ?>
                        </button>
                    </a>
                </p>
                <?php if(auth()->guard()->check()): ?>
                    <p class="card-text">
                        <a href=" # ">
                            <button class="btn btn-warning">
                                Edit
                            </button>
                        </a>
                    </p>

                    <?php if(Auth::user()->user_type > 0): ?>
                        <p class="card-text">
                            <a href=" <?php echo e(route('bands.delete', $band->id)); ?> ">
                                <button class="btn btn-danger">
                                    Delete
                                </button>
                            </a>
                        </p>
                    <?php endif; ?>
                <?php endif; ?>
                </div>
            </div>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\caras\Desktop\sftdev\sftdev\PHP\Bands\resources\views/bands/all_bands.blade.php ENDPATH**/ ?>