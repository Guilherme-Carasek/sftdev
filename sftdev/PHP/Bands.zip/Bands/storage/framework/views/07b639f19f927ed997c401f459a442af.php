<?php $__env->startSection('title'); ?>
    dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>
        Hello <?php echo e(Auth::user()->name); ?> !!!!
    </h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\caras\Desktop\sftdev\sftdev\PHP\Bands\resources\views/dashboard/home_dashboard.blade.php ENDPATH**/ ?>