<?php $__env->startSection('title'); ?>
    <?php echo e($albums[0]->bandName); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?>

    <img id="bandCover" src="<?php echo e($albums[0]->bandPhoto ? asset('storage/' . $albums[0]->bandPhoto) : asset('img/nophoto.png')); ?>" alt="">
    <div class="row">
        <h1><?php echo e($albums[0]->bandName); ?></h1>
    </div>

    <?php if($albums[0]->id): ?>
    <div class="row">
        <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 col-md-6 col-lg-4">
            <div class="card" style="width: 18rem;">
                <img src="<?php echo e($album->albumPhoto ? asset('storage/' . $album->albumPhoto) : asset('img/nophoto.png')); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                <h5 class="card-title"><?php echo e($album->albumName); ?></h5>
                <p class="card-text"> <?php echo e($album->release_date); ?> </p>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->user_type > 0): ?>
                        <a href=" <?php echo e(route('albums.delete'), $album->id); ?> " class="btn btn-primary">Delete</a>
                    <?php endif; ?>
                <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>
        <p>No registered albums yet</p>
        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->user_type > 0): ?>
                <a href=" <?php echo e(route('albums.create')); ?> ">Add new album</a>
            <?php endif; ?>
        <?php endif; ?>

    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\caras\Desktop\sftdev\sftdev\PHP\Bands\resources\views/Albums/show_albums.blade.php ENDPATH**/ ?>