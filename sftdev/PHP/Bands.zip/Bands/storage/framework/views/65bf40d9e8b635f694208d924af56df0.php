<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- link bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href=" <?php echo e(asset('css/style.css')); ?> ">
    <link rel="icon" type="image/x-icon" href=" <?php echo e(asset('img/vynilb.png')); ?> ">
    <title>LaravelRecords <?php echo $__env->yieldContent('title'); ?> </title>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
          <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Home</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(route('bands.index')); ?>">Bands</a>
              </li>
              <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->user_type > 0): ?>
                        <li class="nav-item">
                            <a class="nav-link" href=" <?php echo e(route('bands.create')); ?> ">Add new band</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href=" <?php echo e(route('albums.create')); ?> ">Add new album</a>
                        </li>
                <?php endif; ?>
              <?php endif; ?>
            </ul>
            <?php if(Route::has('login')): ?>
                            <nav class="-mx-3 flex flex-1 justify-end">
                                <?php if(auth()->guard()->check()): ?>
                                <div class="row">
                                    <div class="col">
                                        <a
                                            href="<?php echo e(route('dashboard.home')); ?>"
                                            class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white"
                                        >
                                            Dashboard
                                        </a>
                                    </div>
                                    <div class="col">
                                        <form action=" <?php echo e(route('logout')); ?> " method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-danger">Logout</button>
                                        </form>
                                    </div>
                                </div>
                                <div>

                                </div>
                                <?php else: ?>
                                    <a
                                        href="<?php echo e(route('login')); ?>"
                                        class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white"
                                    >
                                        Log in
                                    </a>

                                    <?php if(Route::has('register')): ?>
                                        <a
                                            href="<?php echo e(route('register')); ?>"
                                            class="rounded-md px-3 py-2 text-black ring-1 ring-transparent transition hover:text-black/70 focus:outline-none focus-visible:ring-[#FF2D20] dark:text-white dark:hover:text-white/80 dark:focus-visible:ring-white"
                                        >
                                            Register
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </nav>
                        <?php endif; ?>
          </div>
        </div>
    </nav>

    <div class="container py-5">
        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <!-- script bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\Users\caras\Desktop\sftdev\sftdev\PHP\Bands\resources\views/layouts/main_layout.blade.php ENDPATH**/ ?>