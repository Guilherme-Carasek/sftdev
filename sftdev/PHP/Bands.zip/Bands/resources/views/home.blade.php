@extends('layouts.main_layout')

@section('title')
Home
@endsection

@section('content')

   <h1> You are home</h1>

@endsection
